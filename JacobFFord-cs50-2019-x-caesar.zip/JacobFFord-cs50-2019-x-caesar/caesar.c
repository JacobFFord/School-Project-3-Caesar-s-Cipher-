#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int main(int argc, string argv[])
{              
    if (argc != 2)
    {
        //checks to make sure the user only enters one argument on the command line
        printf("usage: ./caesar key\n");   
        return 1;
    }
    //ensures that the user enters an int as the argument
    for (int j = 0; j < strlen(argv[1]); j++)
    {
        if (isalpha(argv[1][j]))
        {
            printf("usage: ./caesar key\n");    
            return 1;
        }    
        //get string and store it in variable called "s"
        string s = get_string("plaintext: ");
        //converts command line argument from string to int and stores it in variable called "key"
        int key = atoi(argv[1]);
        //stores string length of "s" in a variable called "n"
        int n = strlen(s);
        printf("ciphertext: ");
        //iterates over each char in "s" applying key to rotate each letter accordingly
        for (int i = 0; i < n; i++)            
        {
            if (isupper(s[i]))
            {
                printf("%c", (s[i] + key - 65) % 26 + 65);
            }
            else if (islower(s[i]))
            {
                printf("%c", (s[i] + key - 97) % 26 + 97);
            }         
            //prints out spaces and symbols unchanged
            else printf("%c", s[i]);
        }
        printf("\n");
        return 0;

        
    
    
    }    
    


 

 
  
       

       
}          
